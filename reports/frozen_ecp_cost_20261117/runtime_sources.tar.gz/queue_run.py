import concurrent.futures,fcntl,json,os,subprocess,sys,threading,time,traceback
from datetime import datetime
from pathlib import Path
from analyze import analyze
ROOT=Path(__file__).resolve().parent
M=json.loads((ROOT/'manifest.json').read_text());LOCK=threading.RLock();SUMMARY_LOCK=threading.Lock();STATE={}

def update(**kw):
    with LOCK:
        STATE.update(kw,updated_at=datetime.now().astimezone().isoformat())
        p=ROOT/'status.json.tmp';p.write_text(json.dumps(STATE,indent=2)+'\n');p.replace(ROOT/'status.json')

def run(index,arm,gpu,smoke=False):
    pair=M['pairs'][index];out=ROOT/('smoke' if smoke else 'runs')/pair['chunk']/arm
    if (out/'complete.json').exists():
        r=json.loads((out/'complete.json').read_text())
        assert r['physics_replay_verified'] and r['model_unchanged'] and r['smoke']==smoke and r['gpu']==gpu
    else:
        while True:
            used=int(subprocess.check_output(['nvidia-smi','-i',str(gpu),'--query-gpu=memory.used','--format=csv,noheader,nounits'],text=True).strip())
            if used<512:break
            time.sleep(15)
        if out.exists():out.rename(out.with_name(out.name+'.incomplete.'+str(time.time_ns())))
        env=dict(os.environ,CUDA_VISIBLE_DEVICES=str(gpu),PHYSICAL_GPU=str(gpu),OMP_NUM_THREADS='2',MKL_NUM_THREADS='2',OPENBLAS_NUM_THREADS='1',
                 PYTHONDONTWRITEBYTECODE='1',SDL_VIDEODRIVER='dummy',SDL_AUDIODRIVER='dummy',WANDB_MODE='disabled',MPLBACKEND='Agg',VALIDATE_GRAPH='0')
        name=('smoke_' if smoke else '')+pair['chunk']+'_'+arm;log=ROOT/'logs'/f'{name}.{time.time_ns()}.log'
        command=[sys.executable,'-u',str(ROOT/'run_job.py'),'--pair',str(index),'--arm',arm]+(['--smoke'] if smoke else [])
        with log.open('x') as f:
            child=subprocess.Popen(command,cwd=ROOT,env=env,stdout=f,stderr=subprocess.STDOUT,stdin=subprocess.DEVNULL)
            with LOCK:STATE['running'][name]=dict(gpu=gpu,pid=child.pid,log=str(log));update()
            code=child.wait()
        with LOCK:STATE['running'].pop(name,None);update()
        if code:raise RuntimeError(f'{name} failed: exit {code}; {log}')
        r=json.loads((out/'complete.json').read_text());assert r['physics_replay_verified'] and r['model_unchanged']
    with LOCK:
        STATE['completed_smokes' if smoke else 'completed_jobs']+=1
        if not smoke:STATE['completed_task_evaluations']+=r['tasks']
        update()

def worker(slot,gpu):
    for index in range(slot,len(M['pairs']),len(M['gpus'])):
        for arm in M['pairs'][index]['order']:run(index,arm,gpu)
        with SUMMARY_LOCK:analyze()
        with LOCK:STATE['completed_pairs']+=1;update()

def main():
    lock=(ROOT/'queue.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    update(state='validating',pid=os.getpid(),started_at=datetime.now().astimezone().isoformat(),completed_jobs=0,completed_smokes=0,
           completed_pairs=0,total_pairs=len(M['pairs']),completed_task_evaluations=0,total_task_evaluations=700,running={})
    try:
        run(0,'off',M['gpus'][0],True)
        triggered=next(i for i,p in enumerate(M['pairs']) if p['chunk']=='chunk_04_I')
        run(triggered,'on',M['gpus'][0],True)
        update(state='benchmarking')
        with concurrent.futures.ThreadPoolExecutor(max_workers=len(M['gpus'])) as pool:
            futures=[pool.submit(worker,i,gpu) for i,gpu in enumerate(M['gpus'])]
            for f in concurrent.futures.as_completed(futures):f.result()
        analyze();update(state='complete',completed_at=datetime.now().astimezone().isoformat())
    except Exception:update(state='failed',error=traceback.format_exc());raise

if __name__=='__main__':main()
