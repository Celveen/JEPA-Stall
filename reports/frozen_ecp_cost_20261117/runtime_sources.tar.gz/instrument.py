"""Synchronized wall timers; no changes to actions, model updates or objectives."""
import json
import time
from pathlib import Path

import torch

CURRENT = None
CALLS = []
EPISODES = []


def install():
    from planning.gd import GDPlanner
    from planning.escape import EscapeMPCPlanner
    from planning.stagnation import StagnationMPCPlanner

    def timed(cls, name, metric):
        original = getattr(cls, name)
        def wrapped(self, *args, **kwargs):
            torch.cuda.synchronize()
            start = time.perf_counter()
            result = original(self, *args, **kwargs)
            torch.cuda.synchronize()
            seconds = time.perf_counter() - start
            owner = CURRENT
            CALLS.append(dict(metric=metric, sample_index=owner._sample_idx if owner else -1,
                              step=owner.iter if owner else -1, seconds=seconds,
                              ecp_active=bool(owner is not None and
                                              (getattr(owner, '_mem', None) is not None or
                                               (hasattr(owner, '_boosting') and owner._boosting())))))
            return result
        setattr(cls, name, wrapped)

    timed(GDPlanner, 'plan', 'gd')
    timed(StagnationMPCPlanner, '_build_mem', 'ecp_build_memory')
    timed(EscapeMPCPlanner, '_post_env_feedback', 'common_feedback')
    timed(StagnationMPCPlanner, '_post_env_feedback', 'ecp_feedback_inclusive')
    original = EscapeMPCPlanner._plan_single

    def episode(self, **kwargs):
        global CURRENT
        previous = CURRENT
        CURRENT = self
        begin = len(CALLS)
        torch.cuda.synchronize()
        torch.cuda.reset_peak_memory_stats()
        start = time.perf_counter()
        try:
            result = original(self, **kwargs)
            torch.cuda.synchronize()
            records = CALLS[begin:]
            sums = {}
            for row in records:
                sums[row['metric']] = sums.get(row['metric'], 0.0) + row['seconds']
            steps = [r for r in self._records if r['sample_idx'] == self._sample_idx]
            row = dict(sample_index=self._sample_idx, success=bool(self.is_success[0]), replans=int(self.iter),
                       controls=int(self.iter * self.n_taken_actions * self.evaluator.frameskip),
                       episode_wall_seconds=time.perf_counter()-start,
                       planner_seconds=sum(r['t_plan_s'] for r in steps),
                       gd_seconds=sums.get('gd',0.0),
                       common_feedback_seconds=sums.get('common_feedback',0.0),
                       ecp_build_memory_seconds=sums.get('ecp_build_memory',0.0),
                       ecp_detector_seconds=max(0.0,sums.get('ecp_feedback_inclusive',0.0)-sums.get('common_feedback',0.0)) if hasattr(self,'_mem') else 0.0,
                       ecp_active_replans=sum(r['metric']=='gd' and r['ecp_active'] for r in records),
                       peak_allocated_bytes=torch.cuda.max_memory_allocated(),
                       peak_reserved_bytes=torch.cuda.max_memory_reserved())
            assert len(steps)==self.iter==sum(r['metric']=='gd' for r in records)
            EPISODES.append(row)
            with Path('cost_episodes.jsonl').open('a') as f:f.write(json.dumps(row)+'\n')
            with Path('cost_calls.jsonl').open('a') as f:
                for r in records:f.write(json.dumps(r)+'\n')
            return result
        finally:
            CURRENT = previous
    EscapeMPCPlanner._plan_single = episode
