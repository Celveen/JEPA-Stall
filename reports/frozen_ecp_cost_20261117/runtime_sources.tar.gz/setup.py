import hashlib,json,shutil
from pathlib import Path
from omegaconf import OmegaConf

BASE=Path('/home/appuser/workspace/project/multimodal-test/JEPA-Stall-cloud-20261116/experiments')
OLD=BASE/'figure1_three_eval_seeds_20261117';ECP=BASE/'figure1_ecp_cudagraph_20261117'
ROOT=BASE/'frozen_ecp_cost_20261117';ROOT.mkdir(exist_ok=False)
shutil.copytree(ECP/'source/resnet',ROOT/'source',symlinks=True)
original=json.loads((ECP/'manifest.json').read_text())
jobs=[j for j in original['jobs'] if j['family']=='frozen' and j['seed']==200]
assert len(jobs)==35 and sum(j['n'] for j in jobs)==350
m=dict(protocol='Full fixed 350-task paired Frozen augmented-checkpoint ECP off/on cost comparison',
       seed=200,checkpoint=jobs[0]['checkpoint'],checkpoint_sha256=original['checkpoints'][jobs[0]['checkpoint']],
       gpus=[0,1,3,5,6],pairs=[],cuda_graph=True,gd_steps=100,replans=30,controls_per_replan=5,
       timing_repetitions=1,source_experiment=str(ECP),
       timing_notes='Same GPU within a pair; alternating arm order; episode timers exclude model loading and independent physics verification. Both arms retain common probe diagnostics and simulator replay. No cross-seed timing replication.')
for i,j in enumerate(jobs):
    chunk=Path(j['key']).name;pair=dict(chunk=chunk,shape=j['shape'],n=j['n'],configs={},references={},order=['off','on'] if i%2==0 else ['on','off'])
    for arm in ('off','on'):
        c=OmegaConf.load(j['config'])
        c.saved_folder=str(ROOT/'runs'/chunk/arm)
        if arm=='off':
            c.planner._target_='planning.escape.EscapeMPCPlanner'
            del c.planner.stag
        assert c.planner.probe.mode=='none' and c.planner.sub_planner.cuda_graph
        path=ROOT/'configs'/chunk/(arm+'.yaml');path.parent.mkdir(parents=True,exist_ok=True);OmegaConf.save(c,path)
        pair['configs'][arm]=str(path)
        reference=(ECP/'runs'/j['key']) if arm=='on' else (OLD/'runs/frozen/aug/seed200'/chunk)
        pair['references'][arm]=str(reference/'final_eval_results.npz')
    m['pairs'].append(pair)
m['source_sha256']={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in (ROOT/'source').rglob('*.py')}
(ROOT/'manifest.json').write_text(json.dumps(m,indent=2)+'\n')
for name in ('instrument.py','run_job.py','queue_run.py','analyze.py','README.md'):shutil.copy2(Path(__file__).with_name(name),ROOT/name)
(ROOT/'logs').mkdir();print(ROOT)
