import argparse
import hashlib
import json
import os
import subprocess
import sys
import time
from pathlib import Path

ROOT=Path(__file__).resolve().parent

def sha(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
    return h.hexdigest()

def model_hash(model):
    h=hashlib.sha256()
    for k,v in model.state_dict().items():h.update(k.encode());h.update(v.detach().cpu().contiguous().numpy().tobytes())
    return h.hexdigest()

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--pair',type=int,required=True)
    parser.add_argument('--arm',choices=['off','on'],required=True);parser.add_argument('--smoke',action='store_true');a=parser.parse_args()
    m=json.loads((ROOT/'manifest.json').read_text());pair=m['pairs'][a.pair]
    sys.path.insert(0,str(ROOT/'source'))
    import numpy as np
    import torch
    from omegaconf import OmegaConf
    import plan
    import instrument
    torch.set_num_threads(2)
    torch.cuda.set_per_process_memory_fraction(10*2**30/torch.cuda.get_device_properties(0).total_memory)
    instrument.install()
    cfg=OmegaConf.load(pair['configs'][a.arm])
    if a.smoke:cfg.n_evals=1
    out=ROOT/('smoke' if a.smoke else 'runs')/pair['chunk']/a.arm
    out.mkdir(parents=True,exist_ok=False);cfg.saved_folder=str(out);OmegaConf.save(cfg,out/'config.yaml')
    checkpoint=Path(m['checkpoint']);assert sha(checkpoint)==m['checkpoint_sha256']
    loaded={};original=plan.load_model
    def load(*args,**kwargs):
        start=time.perf_counter();model=original(*args,**kwargs);torch.cuda.synchronize()
        loaded['load_seconds']=time.perf_counter()-start
        start=time.perf_counter();loaded.update(model=model,before=model_hash(model))
        loaded['hash_seconds']=time.perf_counter()-start
        return model
    plan.load_model=load
    gpu=os.environ['PHYSICAL_GPU']
    gpu_info=subprocess.check_output(['nvidia-smi','-i',gpu,'--query-gpu=index,uuid,name,driver_version,temperature.gpu,clocks.sm,clocks.mem,power.draw','--format=csv,noheader'],text=True).strip()
    os.chdir(out);start=time.perf_counter()
    plan.planning_main(OmegaConf.to_container(cfg,resolve=True));torch.cuda.synchronize()
    main_seconds=time.perf_counter()-start
    assert model_hash(loaded['model'])==loaded['before'],'Frozen model changed'
    assert sha(checkpoint)==m['checkpoint_sha256']
    from datasets.pusht_dset import ACTION_MEAN,ACTION_STD
    from env.pusht.pusht_wrapper import PushTWrapper
    env=PushTWrapper();env.update_env({'shape':'+' if pair['shape']=='plus' else pair['shape']})
    env._render_frame=lambda *args,**kwargs:np.zeros((1,1,3),dtype=np.uint8)
    reference=Path(pair['references'][a.arm])
    with np.load(out/'final_eval_results.npz') as d:
        assert len(d['successes'])==cfg.n_evals and np.isfinite(d['actions']).all()
        assert len(instrument.EPISODES)==cfg.n_evals
        np.testing.assert_array_equal([r['success'] for r in instrument.EPISODES],d['successes'])
        matches=None
        if reference.is_file():
            with np.load(reference) as ref:
                np.testing.assert_array_equal(d['state_0'],ref['state_0'][:cfg.n_evals])
                np.testing.assert_array_equal(d['state_g'],ref['state_g'][:cfg.n_evals])
                np.testing.assert_array_equal(d['successes'],ref['successes'][:cfg.n_evals])
                for i,row in enumerate(instrument.EPISODES):
                    n=row['replans'];np.testing.assert_array_equal(d['actions'][i,:n],ref['actions'][i,:n])
            matches=True
        traces=[];success=[]
        for i in range(cfg.n_evals):
            _,state=env.prepare(int(cfg.seed)*i+1,d['state_0'][i]);states=[state]
            controls=d['actions'][i].reshape(-1,2)*ACTION_STD.numpy()+ACTION_MEAN.numpy()
            for action in controls:
                _,_,_,info=env.step(action);states.append(info['state'])
            last=int(min(d['action_len'][i],len(controls)//5))*5
            success.append(env.eval_state(d['state_g'][i],states[last])['success']);traces.append(states)
        np.testing.assert_array_equal(success,d['successes'])
        np.savez_compressed(out/'replayed_states.npz',states=np.asarray(traces),goals=d['state_g'],successes=d['successes'],action_len=d['action_len'])
        receipt=dict(arm=a.arm,chunk=pair['chunk'],shape=pair['shape'],smoke=a.smoke,tasks=int(cfg.n_evals),
                     successes=int(d['successes'].sum()),checkpoint_sha256=m['checkpoint_sha256'],model_unchanged=True,
                     physics_replay_verified=True,reference_actions_exact=matches,
                     model_parameters=sum(p.numel() for p in loaded['model'].parameters()),
                     gpu=int(gpu),gpu_info=gpu_info,torch_version=torch.__version__,cuda_version=torch.version.cuda,
                     planning_main_seconds=main_seconds,model_load_seconds=loaded['load_seconds'],
                     model_hash_audit_seconds=loaded['hash_seconds'],planning_main_excluding_hash_seconds=main_seconds-loaded['hash_seconds'])
    env.close();(out/'complete.json.tmp').write_text(json.dumps(receipt,indent=2)+'\n');(out/'complete.json.tmp').replace(out/'complete.json');print(json.dumps(receipt),flush=True)

if __name__=='__main__':main()
