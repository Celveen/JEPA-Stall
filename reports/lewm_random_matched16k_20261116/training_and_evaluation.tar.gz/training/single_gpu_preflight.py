from collections import Counter
from pathlib import Path
import gc
import hashlib
import json
import pickle
import sys
import time

ROOT = Path(sys.argv[1]).resolve()
sys.path.insert(0, str(ROOT / 'runtime'))
import hydra
import numpy as np
import torch
from omegaconf import OmegaConf
from models.lewm import SIGReg, build_lewm


def main():
    cfg = OmegaConf.load(ROOT / 'config.yaml')
    original = OmegaConf.load(ROOT / 'reference_training_config.yaml')
    comparison = OmegaConf.create(OmegaConf.to_container(cfg, resolve=True))
    comparison.saved_folder = original.saved_folder
    comparison.env.dataset.data_path = original.env.dataset.data_path
    assert OmegaConf.to_container(comparison, resolve=True) == OmegaConf.to_container(original, resolve=True)
    manifest = json.loads((ROOT / 'manifest.json').read_text())
    data_root = Path(cfg.env.dataset.data_path)
    enhanced_root = data_root.with_name('pushobj_bias_16k')
    dataset_audit = {}
    for split, count in [('train', 16000), ('val', 4000)]:
        random_dir, enhanced_dir = data_root / split, enhanced_root / split
        def load_pickle(directory, name):
            with (directory / name).open('rb') as f:
                return pickle.load(f)
        lengths = load_pickle(random_dir, 'seq_lengths.pkl')
        np.testing.assert_array_equal(lengths, load_pickle(enhanced_dir, 'seq_lengths.pkl'))
        shapes = load_pickle(random_dir, 'shapes.pkl')
        assert list(shapes) == list(load_pickle(enhanced_dir, 'shapes.pkl'))
        assert len(lengths) == count
        assert set(shapes) == {'T', 'L', 'Z', '+'}
        assert set(Counter(shapes).values()) == {count // 4}
        for name in ['states.pth', 'velocities.pth']:
            random_value = torch.load(random_dir / name, map_location='cpu', weights_only=True)
            enhanced_value = torch.load(enhanced_dir / name, map_location='cpu', weights_only=True)
            assert torch.equal(random_value[:, 0], enhanced_value[:, 0]), (split, name)
            del random_value, enhanced_value
        for i in range(count):
            assert (random_dir / 'obses' / f'episode_{i:03d}.mp4').is_file(), (split, i)
        dataset_audit[split] = {'episodes': count, 'shapes': dict(Counter(shapes)),
                               'frames': int(sum(lengths)),
                               'windows': int(sum(max(0, int(x) - 19) for x in lengths)),
                               'matched_lengths_shapes_initial_states_and_velocities': True}
    assert dataset_audit['train']['windows'] == 1630266
    torch.manual_seed(cfg.training.seed)
    np.random.seed(cfg.training.seed)
    datasets, _ = hydra.utils.call(cfg.env.dataset, num_hist=cfg.num_hist, num_pred=cfg.num_pred, frameskip=cfg.frameskip)
    train_set, val_set = datasets['train'], datasets['valid']
    assert len(train_set) == 1630266 and len(val_set) == dataset_audit['val']['windows']
    cfg.model.action_dim = int(train_set.action_dim)
    assert cfg.model.action_dim == 10
    model = build_lewm(cfg.model)
    checkpoint = torch.load(manifest['reference_checkpoint'], map_location='cpu', weights_only=True)
    model.load_state_dict(checkpoint['model'], strict=True)
    assert checkpoint['epoch'] == 10 and checkpoint['step'] == 127360
    del checkpoint, model
    gc.collect()
    torch.manual_seed(cfg.training.seed)
    model = build_lewm(cfg.model).cuda()
    sigreg = SIGReg(**cfg.training.sigreg).cuda()
    indices = np.linspace(0, len(train_set)-1, cfg.training.batch_size, dtype=int)
    loader = torch.utils.data.DataLoader(torch.utils.data.Subset(train_set, indices),
                                        batch_size=cfg.training.batch_size, num_workers=4)
    obs, actions, _ = next(iter(loader))
    visual, actions = obs['visual'].cuda(), actions.cuda()
    assert visual.shape == (128, 4, 3, 224, 224) and actions.shape == (128, 4, 10)
    optimizer = torch.optim.AdamW(model.parameters(), lr=cfg.training.lr, weight_decay=cfg.training.weight_decay)
    durations = []
    torch.cuda.reset_peak_memory_stats()
    for step in range(3):
        torch.cuda.synchronize()
        start = time.time()
        with torch.autocast('cuda', dtype=torch.bfloat16):
            losses = model.loss(visual, actions, sigreg, cfg.training.sigreg_weight)
        assert all(torch.isfinite(value).item() for value in losses)
        optimizer.zero_grad(set_to_none=True)
        losses[0].backward()
        grad_norm = torch.nn.utils.clip_grad_norm_(model.parameters(), cfg.training.grad_clip)
        assert torch.isfinite(grad_norm).item()
        optimizer.step()
        torch.cuda.synchronize()
        durations.append(time.time()-start)
    result = {'passed': True, 'allowed_config_changes_only': True, 'dataset_audit': dataset_audit,
              'reference_weights_load_strictly': True, 'training_starts_from_scratch': True,
              'finite_full_batch_forward_backward': True, 'batch_shape': list(visual.shape),
              'gpu': torch.cuda.get_device_name(), 'torch': torch.__version__,
              'cuda': torch.version.cuda, 'parameters': sum(p.numel() for p in model.parameters()),
              'step_seconds': durations, 'peak_gpu_memory_gib': torch.cuda.max_memory_allocated()/1024**3,
              'preflight_only_no_training_checkpoint_saved': True}
    (ROOT / 'preflight.json').write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps(result, indent=2), flush=True)


if __name__ == '__main__':
    main()
