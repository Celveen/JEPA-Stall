"""Run the unchanged reference trainer and retain progress/completion receipts."""
from datetime import datetime, timedelta
from pathlib import Path
from zoneinfo import ZoneInfo
import hashlib
import json
import os
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
ZONE = ZoneInfo('Asia/Shanghai')


def save_status(data):
    data['updated_at'] = datetime.now(ZONE).isoformat()
    temporary = ROOT / 'status.json.tmp'
    temporary.write_text(json.dumps(data, indent=2) + '\n')
    temporary.replace(ROOT / 'status.json')


def main():
    manifest = json.loads((ROOT / 'manifest.json').read_text())
    assert json.loads((ROOT / 'preflight.json').read_text())['distributed_bn_recalibration_and_validation_smoke_passed']
    output = Path(manifest['output'])
    assert not output.exists(), 'Output already exists; do not overwrite or restart training'
    for name, receipt in manifest['source_files'].items():
        assert hashlib.sha256((ROOT / 'runtime' / name).read_bytes()).hexdigest() == receipt['sha256'], name
    for name, digest in manifest['additional_runtime_files'].items():
        assert hashlib.sha256((ROOT / 'runtime' / name).read_bytes()).hexdigest() == digest, name
    memory = subprocess.check_output([
        'nvidia-smi', '--id=' + ','.join(manifest['gpu_uuids']), '--query-gpu=memory.free',
        '--format=csv,noheader,nounits'], text=True).strip()
    free = [int(value) for value in memory.splitlines()]
    assert len(free) == 8 and min(free) >= 8192, 'Insufficient free memory; leave other GPU processes alone'
    env = dict(os.environ)
    env.update(CUDA_VISIBLE_DEVICES=','.join(manifest['gpu_uuids']), OMP_NUM_THREADS='1',
               MKL_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1', PYTHONUNBUFFERED='1')
    command = [manifest['python'], '-u', '-m', 'torch.distributed.run', '--standalone', '--nproc_per_node=8', str(ROOT / manifest['entrypoint']), str(ROOT / 'config.yaml')]
    (ROOT / 'command.json').write_text(json.dumps({'command': command, 'cwd': str(ROOT / 'runtime'),
        'environment_overrides': {k: env[k] for k in ['CUDA_VISIBLE_DEVICES', 'OMP_NUM_THREADS', 'MKL_NUM_THREADS', 'OPENBLAS_NUM_THREADS']}}, indent=2) + '\n')
    started = time.time()
    status = {'state': 'starting', 'supervisor_pid': os.getpid(), 'started_at': datetime.now(ZONE).isoformat(),
              'gpu_indices': manifest['gpu_indices'], 'gpu_uuids': manifest['gpu_uuids'], 'gpu_count': 8,
              'output': str(output), 'target_epochs': 10, 'target_steps': 127360,
              'initialization': 'from scratch'}
    with (ROOT / 'train.log').open('wb') as log:
        child = subprocess.Popen(command, cwd=ROOT / 'runtime', env=env,
                                 stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT)
        status.update(state='training', training_pid=child.pid)
        save_status(status)
        while child.poll() is None:
            metrics = output / 'metrics.jsonl'
            if metrics.exists():
                rows = []
                for line in metrics.read_text().splitlines():
                    try:
                        rows.append(json.loads(line))
                    except json.JSONDecodeError:
                        continue
                if rows:
                    status['latest_metrics'] = rows[-1]
                    step = int(rows[-1]['step'])
                    elapsed = time.time() - started
                    status.update(completed_steps=step, elapsed_hours=elapsed / 3600)
                    if step >= 200:
                        remaining = elapsed / step * (127360-step)
                        status.update(estimated_remaining_hours=remaining / 3600,
                                      estimated_finish_at=(datetime.now(ZONE)+timedelta(seconds=remaining)).isoformat())
            save_status(status)
            time.sleep(10)
        status['exit_code'] = child.returncode
    if child.returncode:
        status.update(state='failed', elapsed_hours=(time.time()-started)/3600)
        save_status(status)
        raise SystemExit(child.returncode)

    sys.path.insert(0, str(ROOT / 'runtime'))
    import torch
    from omegaconf import OmegaConf
    from models.lewm import build_lewm
    cfg = OmegaConf.load(output / 'hydra.yaml')
    final = output / 'checkpoints/model_10.pth'
    payload = torch.load(final, map_location='cpu', weights_only=True)
    latest = torch.load(output / 'checkpoints/model_latest.pth', map_location='cpu', weights_only=True)
    assert payload['epoch'] == latest['epoch'] == 10
    assert payload['step'] == latest['step'] == 127360
    model = build_lewm(cfg.model)
    model.load_state_dict(payload['model'], strict=True)
    for key, value in payload['model'].items():
        assert torch.isfinite(value).all(), key
        assert torch.equal(value, latest['model'][key]), key
    rows = [json.loads(line) for line in (output / 'metrics.jsonl').read_text().splitlines()]
    validations = [row for row in rows if 'val' in row]
    assert [row['epoch'] for row in validations] == list(range(1, 11))
    result = {'checkpoint': str(final), 'sha256': hashlib.sha256(final.read_bytes()).hexdigest(),
              'epoch': 10, 'step': 127360, 'finite_parameters_and_buffers': True,
              'strict_model_load': True, 'latest_tensor_identical': True,
              'final_validation': validations[-1], 'validation_history': validations,
              'elapsed_hours': (time.time()-started)/3600,
              'downstream_planning_evaluation': 'not started'}
    (ROOT / 'training_result.json').write_text(json.dumps(result, indent=2)+'\n')
    status.update(state='complete', completed_steps=127360, epoch=10, result=str(ROOT/'training_result.json'),
                  elapsed_hours=result['elapsed_hours'])
    status.pop('estimated_remaining_hours', None)
    status.pop('estimated_finish_at', None)
    save_status(status)
    print(json.dumps(result, indent=2), flush=True)


if __name__ == '__main__':
    try:
        main()
    except Exception as exc:
        path = ROOT / 'status.json'
        status = json.loads(path.read_text()) if path.exists() else {}
        status.update(state='failed', error=f'{type(exc).__name__}: {exc}')
        save_status(status)
        raise
