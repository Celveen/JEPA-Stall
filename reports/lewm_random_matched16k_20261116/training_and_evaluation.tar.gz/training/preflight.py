"""Check global-loss/gradient equivalence, bf16 propagation, and native checkpoints."""
from pathlib import Path
import copy
import gc
import json
import sys
import time

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT/'runtime'))
import hydra
import numpy as np
import torch
from omegaconf import OmegaConf
from models.lewm import SIGReg, build_lewm
from encoder_parallel import parallelize_encoder


def sync():
    for i in range(8):
        torch.cuda.synchronize(i)


def parameter_map(model):
    return {name.replace('encoder.module.model.', 'encoder.'): value
            for name,value in model.named_parameters()}


def main():
    assert torch.cuda.device_count() == 8
    cfg=OmegaConf.load(ROOT/'config.yaml')
    original=OmegaConf.load(ROOT/'reference_training_config.yaml')
    check=OmegaConf.create(OmegaConf.to_container(cfg,resolve=True))
    check.saved_folder=original.saved_folder
    check.env.dataset.data_path=original.env.dataset.data_path
    assert OmegaConf.to_container(check,resolve=True)==OmegaConf.to_container(original,resolve=True)
    prior=json.loads((ROOT/'single_gpu_preflight.json').read_text())
    assert prior['passed']
    torch.manual_seed(0);np.random.seed(0)
    datasets,_=hydra.utils.call(cfg.env.dataset,num_hist=cfg.num_hist,num_pred=cfg.num_pred,frameskip=cfg.frameskip)
    ds=datasets['train'];cfg.model.action_dim=ds.action_dim
    indices=np.linspace(0,len(ds)-1,128,dtype=int)
    loader=torch.utils.data.DataLoader(torch.utils.data.Subset(ds,indices),batch_size=128,num_workers=4)
    obs,act,_=next(iter(loader));visual=obs['visual'].cuda();act=act.cuda()
    plain=build_lewm(cfg.model).cuda()
    parallel=parallelize_encoder(copy.deepcopy(plain),list(range(8)))
    assert list(plain.state_dict())==list(parallel.state_dict())
    for k,v in plain.state_dict().items():assert torch.equal(v,parallel.state_dict()[k]),k
    regularizer=SIGReg(**cfg.training.sigreg).cuda()
    losses=[]
    for model in [plain,parallel]:
        torch.manual_seed(987)
        with torch.autocast('cuda',enabled=False):
            values=model.loss(visual[:16],act[:16],regularizer,cfg.training.sigreg_weight)
        values[0].backward()
        losses.append([float(v) for v in values])
    np.testing.assert_allclose(losses[0],losses[1],rtol=2e-4,atol=2e-5)
    left,right=parameter_map(plain),parameter_map(parallel)
    assert left.keys()==right.keys()
    numerator=denominator=0.
    maximum=0.
    for key in left:
        a,b=left[key].grad,right[key].grad
        assert (a is None)==(b is None),key
        if a is not None:
            difference=(a-b).float()
            maximum=max(maximum,float(difference.abs().max()))
            numerator+=float(difference.square().sum())
            denominator+=float(a.float().square().sum())
    relative=(numerator/max(denominator,1e-30))**.5
    assert relative<2e-3,relative
    for name,module in plain.named_modules():
        if isinstance(module,torch.nn.modules.batchnorm._BatchNorm):
            counterpart=dict(parallel.named_modules())[name]
            torch.testing.assert_close(module.running_mean,counterpart.running_mean,rtol=2e-4,atol=2e-5)
            torch.testing.assert_close(module.running_var,counterpart.running_var,rtol=2e-4,atol=2e-5)
            assert torch.equal(module.num_batches_tracked,counterpart.num_batches_tracked)
    plain.load_state_dict(parallel.state_dict(),strict=True)
    del plain,left,right;gc.collect();torch.cuda.empty_cache()
    parallel.zero_grad(set_to_none=True)
    audit=[];parallel.encoder.module.audit_records=audit
    optimizer=torch.optim.AdamW(parallel.parameters(),lr=cfg.training.lr,weight_decay=cfg.training.weight_decay)
    times=[]
    for i in range(8):torch.cuda.reset_peak_memory_stats(i)
    for step in range(12):
        sync();start=time.time()
        with torch.autocast('cuda',dtype=torch.bfloat16):
            values=parallel.loss(visual,act,regularizer,cfg.training.sigreg_weight)
        assert all(torch.isfinite(value).item() for value in values)
        optimizer.zero_grad(set_to_none=True);values[0].backward()
        norm=torch.nn.utils.clip_grad_norm_(parallel.parameters(),cfg.training.grad_clip)
        assert torch.isfinite(norm).item();optimizer.step();sync()
        times.append(time.time()-start)
    assert {r['device'] for r in audit}==set(range(8))
    assert all(r['amp_enabled'] and r['amp_dtype']=='torch.bfloat16' for r in audit)
    result={'passed':True,'eight_gpu':True,'configuration_changes_only_paths':True,
        'dataset_audit':prior['dataset_audit'],'fp32_losses_single_vs_parallel':losses,
        'gradient_relative_l2_error':relative,'gradient_max_absolute_error':maximum,
        'global_batchnorm_statistics_match':True,'sigreg_computed_on_full_batch':True,
        'native_checkpoint_keys_and_strict_load':True,'bf16_propagation_all_devices':True,
        'benchmark_step_seconds':times,'steady_step_seconds_median':float(np.median(times[3:])),
        'peak_memory_gib_by_device':[torch.cuda.max_memory_allocated(i)/1024**3 for i in range(8)],
        'global_batch':128,'parameters':sum(p.numel() for p in parallel.parameters()),
        'no_training_checkpoint_saved':True}
    (ROOT/'preflight.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2),flush=True)


if __name__=='__main__':main()
