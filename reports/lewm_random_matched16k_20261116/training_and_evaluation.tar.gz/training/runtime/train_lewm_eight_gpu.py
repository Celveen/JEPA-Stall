"""Use the reference recipe unchanged with an encoder-only eight-GPU adapter."""
import torch
import train_lewm as reference
from encoder_parallel import parallelize_encoder

original_build = reference.build_lewm


def build_parallel(cfg):
    assert torch.cuda.device_count() == 8, 'Expected all eight configured GPUs'
    return parallelize_encoder(original_build(cfg), list(range(8)))


if __name__ == '__main__':
    reference.build_lewm = build_parallel
    reference.main()
