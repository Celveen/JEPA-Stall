"""Parallelize only frame-independent ViT encoding; preserve global losses and BN."""
import torch
from torch import nn


class _PrecisionReplica(nn.Module):
    def __init__(self, model):
        super().__init__()
        self.model = model
        self.amp_enabled = False
        self.amp_dtype = torch.bfloat16
        self.audit_records = None

    def forward(self, visual):
        # PyTorch 2.3 DataParallel starts worker autocast with its default dtype.
        # Explicitly restore the caller's bf16 (or disabled/FP32) context.
        with torch.autocast('cuda', enabled=self.amp_enabled, dtype=self.amp_dtype):
            if self.audit_records is not None:
                self.audit_records.append({'device': visual.device.index,
                    'amp_enabled': torch.is_autocast_enabled(),
                    'amp_dtype': str(torch.get_autocast_gpu_dtype())})
            return self.model(visual)


class EncoderDataParallel(nn.DataParallel):
    def __init__(self, encoder, device_ids):
        assert not any(isinstance(m, nn.modules.batchnorm._BatchNorm) for m in encoder.modules())
        assert not any(isinstance(m, nn.Dropout) and m.p != 0 for m in encoder.modules())
        super().__init__(_PrecisionReplica(encoder), device_ids=device_ids, output_device=device_ids[0])

    def forward(self, visual):
        self.module.amp_enabled = torch.is_autocast_enabled()
        self.module.amp_dtype = torch.get_autocast_gpu_dtype()
        return super().forward(visual)

    def state_dict(self, *args, destination=None, prefix='', keep_vars=False):
        # Save exactly the original encoder keys for existing LeWM evaluators.
        return self.module.model.state_dict(*args, destination=destination,
                                            prefix=prefix, keep_vars=keep_vars)


def parallelize_encoder(model, device_ids):
    model.encoder = EncoderDataParallel(model.encoder, device_ids=device_ids)
    return model
