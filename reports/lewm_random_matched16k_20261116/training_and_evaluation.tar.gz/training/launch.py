from pathlib import Path
import json
import subprocess
import sys

root = Path(__file__).resolve().parent
assert not (root / 'launch.json').exists(), 'A launch already exists; inspect status instead of duplicating it'
with (root / 'supervisor.log').open('wb') as log:
    process = subprocess.Popen([sys.executable, '-u', str(root / 'run_training.py')], cwd=root,
                               stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT,
                               start_new_session=True)
record = {'supervisor_pid': process.pid, 'status': str(root / 'status.json'), 'log': str(root / 'train.log')}
(root / 'launch.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record, indent=2))
