"""Wait for a verified final checkpoint, then run matched native and ECP arms."""
import concurrent.futures
import fcntl
import json
import os
import queue
import subprocess
import sys
import time

from common import ARMS, ROOT, SHAPES, TRAIN, now, save_json, verified_checkpoint, verify_assets


def main():
    lock = (ROOT / 'queue.lock').open('a')
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    state = {'state': 'waiting_for_training', 'pid': os.getpid(), 'started_at': now(),
             'training': str(TRAIN), 'tasks_per_arm': 350, 'arms': list(ARMS), 'jobs': []}

    def update(**kwargs):
        state.update(**kwargs, updated_at=now())
        save_json(ROOT / 'status.json', state)

    try:
        verify_assets()
        while True:
            training = json.loads((TRAIN / 'status.json').read_text())
            if training['state'] == 'complete':
                break
            if training['state'] == 'failed':
                raise RuntimeError(f'Training failed: {training.get("error", training.get("exit_code"))}')
            os.kill(int(training['supervisor_pid']), 0)
            update(training_progress={k: training.get(k) for k in
                                      ('completed_steps', 'target_steps', 'estimated_finish_at', 'updated_at')})
            time.sleep(30)
        checkpoint = verified_checkpoint()
        verify_assets()
        save_json(ROOT / 'checkpoint_receipt.json', checkpoint)
        update(state='evaluating', checkpoint_sha256=checkpoint['sha256'], evaluation_started_at=now())
        available = queue.Queue()
        for gpu in range(8):
            available.put(gpu)
        (ROOT / 'logs').mkdir(exist_ok=True)

        def job(arm, shape):
            gpu = available.get()
            try:
                env = dict(os.environ, CUDA_VISIBLE_DEVICES=str(gpu), OMP_NUM_THREADS='2',
                           MKL_NUM_THREADS='2', OPENBLAS_NUM_THREADS='2', NUMEXPR_NUM_THREADS='2',
                           PYTHONUNBUFFERED='1', PYTHONDONTWRITEBYTECODE='1',
                           SDL_VIDEODRIVER='dummy', MPLBACKEND='Agg', WANDB_MODE='disabled')
                log_path = ROOT / 'logs' / f'{arm}_{shape}.log'
                command = [sys.executable, str(ROOT / 'run_eval.py'), '--arm', arm, '--shape', shape]
                with log_path.open('x') as log:
                    child = subprocess.Popen(command, cwd=ROOT, env=env, stdout=log, stderr=subprocess.STDOUT)
                    save_json(ROOT / 'logs' / f'{arm}_{shape}.launch.json',
                              {'pid': child.pid, 'gpu': gpu, 'command': command, 'started_at': now()})
                    returncode = child.wait()
                return {'arm': arm, 'shape': shape, 'gpu': gpu, 'returncode': returncode, 'log': str(log_path)}
            finally:
                available.put(gpu)

        with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
            futures = [pool.submit(job, arm, shape) for arm in ARMS for shape in SHAPES]
            for future in concurrent.futures.as_completed(futures):
                state['jobs'].append(future.result())
                update(completed_jobs=len(state['jobs']))
        assert all(item['returncode'] == 0 for item in state['jobs']), 'Evaluation job failed; see logs'
        update(state='replaying_and_summarizing')
        with (ROOT / 'replay.log').open('x') as log:
            subprocess.run([sys.executable, str(ROOT / 'replay_and_summarize.py')], cwd=ROOT,
                           env=dict(os.environ, OMP_NUM_THREADS='1', MKL_NUM_THREADS='1',
                                    OPENBLAS_NUM_THREADS='1', PYTHONDONTWRITEBYTECODE='1',
                                    CUDA_VISIBLE_DEVICES='', SDL_VIDEODRIVER='dummy'),
                           stdout=log, stderr=subprocess.STDOUT, check=True)
        update(state='complete', completed_at=now(), results=str(ROOT / 'RESULTS.md'))
    except Exception as exc:
        update(state='failed', error=f'{type(exc).__name__}: {exc}')
        raise


if __name__ == '__main__':
    main()
