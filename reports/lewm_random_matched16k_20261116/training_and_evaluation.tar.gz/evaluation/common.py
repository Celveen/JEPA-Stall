import hashlib
import json
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]
SOURCE = REPO / 'reports/lewm_contact_schedule_20261113/lewm_ecp_045_contact_objective/source'
TRAIN = REPO / 'experiments/lewm_random_matched16k_8gpu_20261116'
MODEL = REPO / 'checkpoints/lewm_pushobj_random_matched16k_e10_8gpu_20261116'
SHAPES = ('I', 'L', 'square', 'Z', 'small_tee', 'plus', 'T')
ARMS = ('native', 'ecp')


def now():
    return datetime.now().astimezone().isoformat()


def sha256(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(1048576), b''):
            h.update(chunk)
    return h.hexdigest()


def save_json(path, value):
    path = Path(path)
    temporary = path.with_suffix(path.suffix + '.tmp')
    temporary.write_text(json.dumps(value, indent=2) + '\n')
    temporary.replace(path)


def verify_assets():
    manifest = json.loads((ROOT / 'asset_manifest.json').read_text())
    for group, base in (('source', SOURCE), ('assets', ROOT)):
        for relative, digest in manifest[group].items():
            assert sha256(base / relative) == digest, f'Changed {group}: {relative}'


def verified_checkpoint():
    status = json.loads((TRAIN / 'status.json').read_text())
    assert status['state'] == 'complete', 'Training is not complete'
    result = json.loads((TRAIN / 'training_result.json').read_text())
    expected = MODEL / 'checkpoints/model_10.pth'
    assert Path(result['checkpoint']).resolve() == expected.resolve()
    assert result['epoch'] == 10 and result['step'] == 127360
    for key in ('finite_parameters_and_buffers', 'strict_model_load', 'latest_tensor_identical'):
        assert result[key] is True, key
    assert sha256(expected) == result['sha256'], 'Final checkpoint hash differs'
    return result
