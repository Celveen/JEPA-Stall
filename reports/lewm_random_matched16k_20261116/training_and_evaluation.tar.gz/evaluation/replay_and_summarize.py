"""Verify all 700 outcomes by physics replay, then report paired comparisons."""
import csv
import json
import multiprocessing as mp
import sys

from common import ARMS, ROOT, SHAPES, SOURCE, now, save_json, verified_checkpoint


def replay_shape(shape):
    sys.path.insert(0, str(SOURCE))
    import numpy as np
    from datasets.pusht_dset import ACTION_MEAN, ACTION_STD
    from env.pusht.pusht_wrapper import PushTWrapper
    env = PushTWrapper()
    env.update_env({'shape': '+' if shape == 'plus' else shape})
    env._render_frame = lambda *args, **kwargs: np.zeros((1, 1, 3), dtype=np.uint8)
    touched = False

    def contact(arbiter, space, data):
        nonlocal touched
        a, b = (s.body for s in arbiter.shapes)
        if (a == env.agent and b == env.block) or (b == env.agent and a == env.block):
            touched = True

    for arm in ARMS:
        output = ROOT / 'full' / arm / shape
        with np.load(output / 'final_eval_results.npz') as data:
            controls = data['actions'].reshape(50, -1, 2) * ACTION_STD.numpy() + ACTION_MEAN.numpy()
            horizon = data['actions'].shape[1]
            state_traces, contact_traces, outcomes = [], [], []
            for i, (start, goal, commands) in enumerate(zip(data['state_0'], data['state_g'], controls)):
                _, state = env.prepare(2000 * i + 1, start)
                env.collision_handeler.post_solve = contact
                states, contacts = [state], []
                for command in commands:
                    touched = False
                    _, _, _, info = env.step(command)
                    states.append(info['state'])
                    contacts.append(touched)
                last = int(min(data['action_len'][i], horizon)) * 5
                outcomes.append(env.eval_state(goal, states[last])['success'])
                state_traces.append(states)
                contact_traces.append(contacts)
            np.testing.assert_array_equal(outcomes, data['successes'], err_msg=f'{arm}/{shape}')
            np.savez_compressed(output / 'replayed_trajectories.npz', states=np.asarray(state_traces),
                                contacts=np.asarray(contact_traces), goals=data['state_g'],
                                successes=data['successes'], action_len=data['action_len'])
        save_json(output / 'replay_check.json', {'verified': True, 'episodes': 50, 'timestamp': now()})
    env.close()
    return shape


def summarize():
    import numpy as np
    rows, paired_rows = [], []
    expected = verified_checkpoint()['sha256']
    digests = set()
    for shape in SHAPES:
        values = {}
        for family, directory in (('random', ROOT / 'full'), ('augmented', ROOT / 'reference_augmented')):
            for arm in ARMS:
                path = directory / arm / shape
                with np.load(path / 'final_eval_results.npz') as result:
                    values[f'{family}_{arm}'] = result['successes'].astype(bool)
                if family == 'random':
                    summary = json.loads((path / 'summary.json').read_text())
                    assert summary['checkpoint_sha256'] == expected and summary['model_unchanged']
                    digests.add(summary['model_state_sha256'])
                    assert json.loads((path / 'replay_check.json').read_text())['verified']
        native, ecp = values['random_native'], values['random_ecp']
        row = {'shape': shape, 'tasks': 50,
               **{key: int(value.sum()) for key, value in values.items()},
               'random_ecp_rescues': int((~native & ecp).sum()),
               'random_ecp_regressions': int((native & ~ecp).sum())}
        # Preserve exact pre-intervention alignment within the new checkpoint.
        with np.load(ROOT / 'full/native' / shape / 'final_eval_results.npz') as a, \
             np.load(ROOT / 'full/ecp' / shape / 'final_eval_results.npz') as b:
            np.testing.assert_allclose(a['actions'][:, :10], b['actions'][:, :10], rtol=0, atol=1e-6)
        records = [json.loads(line) for line in (ROOT / 'full/ecp' / shape / 'lewm_contact_objective.jsonl').read_text().splitlines()] if (ROOT / 'full/ecp' / shape / 'lewm_contact_objective.jsonl').exists() else []
        interventions = [item for record in records for item in record['actions']]
        row['contact_guided_episodes'] = len({item['sample_idx'] for item in interventions})
        row['contact_guided_replans'] = len(interventions)
        rows.append(row)
        for i in range(50):
            paired_rows.append({'shape': shape, 'task_index': i, 'seed': 2000*i+1,
                                **{key: int(value[i]) for key, value in values.items()}})
    assert len(digests) == 1, 'Evaluation arms used different model states'
    total = {'shape': 'All', **{key: sum(row[key] for row in rows) for key in rows[0] if key != 'shape'}}
    for filename, items in (('per_shape.csv', rows + [total]), ('paired_tasks.csv', paired_rows)):
        with (ROOT / filename).open('w', newline='') as file:
            writer = csv.DictWriter(file, fieldnames=list(items[0]))
            writer.writeheader()
            writer.writerows(items)
    report = {'state': 'complete', 'completed_at': now(), 'checkpoint_sha256': expected,
              'physics_replayed_episodes': 700, 'matched_tasks': True,
              'first_ten_replans_match': True, 'rows': rows, 'total': total}
    save_json(ROOT / 'results.json', report)
    lines = ['# Random-data LeWM: matched PushObj evaluation', '',
             'Final epoch 10; 350 tasks per arm; GD 100 iterations; 30 MPC replans × 5 controls.',
             'All 700 new outcomes verified by independent physics replay. Model parameters and buffers stayed frozen.', '',
             '| Shape | Random native | Random + ECP | Augmented native | Augmented + ECP |',
             '|---|---:|---:|---:|---:|']
    for row in rows + [total]:
        values = [f"{100*row[key]/row['tasks']:.2f}% ({row[key]}/{row['tasks']})" for key in
                  ('random_native', 'random_ecp', 'augmented_native', 'augmented_ecp')]
        lines.append('| ' + row['shape'] + ' | ' + ' | '.join(values) + ' |')
    lines.extend(['', f"Random-data ECP paired outcomes: {total['random_ecp_rescues']} rescues, {total['random_ecp_regressions']} regressions.",
                  '', 'Augmented results are the archived matched runs; they were not rerun or mixed with other task sets.',
                  'ECP uses stagnation thresholds 0.15/0.45, memory regularization, and contact optimization weight 10 with conditional analytic proprioceptive guidance. No post-optimization action offset is used.',
                  'See `paired_tasks.csv`, `per_shape.csv`, and `full/<arm>/<shape>/replayed_trajectories.npz` for outcomes and trajectories.', ''])
    (ROOT / 'RESULTS.md').write_text('\n'.join(lines))


if __name__ == '__main__':
    with mp.get_context('spawn').Pool(7) as pool:
        for shape in pool.imap_unordered(replay_shape, SHAPES):
            print(shape, 'all 100 outcomes replay-verified', flush=True)
    summarize()
