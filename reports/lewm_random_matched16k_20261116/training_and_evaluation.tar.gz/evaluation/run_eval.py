"""Frozen LeWM evaluation using the exact augmented-model planning protocol."""
import argparse
import hashlib
import os
import sys
import time
from pathlib import Path

from common import ARMS, ROOT, SHAPES, SOURCE, save_json, verified_checkpoint


def model_digest(model):
    digest = hashlib.sha256()
    for name, tensor in model.state_dict().items():
        digest.update(name.encode())
        digest.update(tensor.detach().cpu().contiguous().numpy().tobytes())
    return digest.hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--shape', choices=SHAPES, required=True)
    parser.add_argument('--arm', choices=ARMS, required=True)
    args = parser.parse_args()
    receipt = verified_checkpoint()
    sys.path.insert(0, str(SOURCE))
    import numpy as np
    import torch
    from omegaconf import OmegaConf
    import plan

    assert torch.cuda.is_available(), 'CUDA required for full evaluation'
    torch.set_num_threads(2)
    cfg = OmegaConf.load(ROOT / 'configs' / args.arm / f'{args.shape}.yaml')
    output = Path(cfg.saved_folder)
    output.mkdir(parents=True, exist_ok=False)
    OmegaConf.save(cfg, output / 'config.yaml')
    original_load = plan.load_model
    loaded = {}

    def load_frozen(*values, **kwargs):
        model = original_load(*values, **kwargs)
        model.requires_grad_(False).eval()
        loaded.update(model=model, digest=model_digest(model))
        return model

    plan.load_model = load_frozen
    os.chdir(output)
    started = time.monotonic()
    plan.planning_main(OmegaConf.to_container(cfg, resolve=True))
    assert model_digest(loaded['model']) == loaded['digest'], 'Model changed in evaluation'
    with np.load(output / 'final_eval_results.npz') as result:
        with np.load(ROOT / 'reference_augmented' / args.arm / args.shape / 'final_eval_results.npz') as reference:
            for key in ('state_0', 'state_g'):
                np.testing.assert_array_equal(result[key], reference[key])
        assert len(result['successes']) == 50
        assert result['actions'].shape[0] == 50 and result['actions'].shape[2] == 10
        assert 1 <= result['actions'].shape[1] <= 30
        assert np.isfinite(result['actions']).all()
        summary = {
            'arm': args.arm, 'shape': args.shape, 'tasks': 50,
            'successes': int(result['successes'].sum()),
            'model_state_sha256': loaded['digest'], 'model_unchanged': True,
            'checkpoint_sha256': receipt['sha256'], 'checkpoint_epoch': 10,
            'matched_augmented_start_goal_states': True,
            'wall_seconds': time.monotonic() - started,
        }
    save_json(output / 'summary.json', summary)
    print(summary, flush=True)


if __name__ == '__main__':
    main()
