# Figure 1 ECP priority evaluation

Frozen and AdaJEPA seeds 200/300; LeWM seeds 2001/2002. Each condition/seed retains 350 original tasks.
GD100, 30 replans, 5 controls, unchanged checkpoint hashes and ECP/contact weights.
CUDA Graph ported from Celveen/SE-JEPA cudagraph-gd aa397f3.
Recapture each planning call because ECP closes over dynamic memory/targets/indices.
Use action_objective in captured path to retain LeWM proprio/contact losses.
Three 30-replan smoke evaluations compare eager/graph actions bitwise and RNG on every planning call, then validate physics replay.
Only after validation passes reuse completed original GD results, retaining receipts with provenance; incomplete jobs are rerun here.
Other six conditions are deferred. Original queue and partial outputs remain archived in place.
GPU 2 is excluded. Resume this queue with its existing manifest; complete receipts are skipped.
