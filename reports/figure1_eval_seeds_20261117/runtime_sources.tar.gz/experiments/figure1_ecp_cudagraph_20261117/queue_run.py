import concurrent.futures, fcntl, json, os, subprocess, sys, threading, time, traceback, queue, shutil
from pathlib import Path
from datetime import datetime
ROOT=Path(__file__).resolve().parent
MANIFEST=json.loads((ROOT/'manifest.json').read_text())
OLD=Path(MANIFEST['previous_experiment'])
LOCK=threading.RLock(); STATE={}; GPUS=queue.Queue()
def update(**kw):
 with LOCK:
  STATE.update(kw,updated_at=datetime.now().astimezone().isoformat())
  p=ROOT/'status.json.tmp';p.write_text(json.dumps(STATE,indent=2)+'\n');p.replace(ROOT/'status.json')
def run(index,smoke=False):
 job=MANIFEST['jobs'][index]
 out=ROOT/('smoke_trigger' if smoke=='trigger' else 'smoke')/job['family']/job['stage'] if smoke else ROOT/'runs'/job['key']
 if (out/'complete.json').exists():
  r=json.loads((out/'complete.json').read_text());assert r['physics_replay_verified'] and r['smoke']==bool(smoke)
  if smoke:
   checks=[json.loads(l) for l in (out/'graph_validation.jsonl').read_text().splitlines()]
   assert checks and all(c['exact'] and c['rng_equal'] for c in checks)
  with LOCK:
   STATE['completed_smokes' if smoke else 'completed_jobs']+=1
   if not smoke:STATE['completed_tasks']+=r['tasks']
   update()
  return
 gpu=GPUS.get()
 try:
  if out.exists():out.rename(out.with_name(out.name+'.incomplete.'+str(time.time_ns())))
  env=dict(os.environ,CUDA_VISIBLE_DEVICES=str(gpu),OMP_NUM_THREADS='2',MKL_NUM_THREADS='2',OPENBLAS_NUM_THREADS='1',PYTHONDONTWRITEBYTECODE='1',SDL_VIDEODRIVER='dummy',SDL_AUDIODRIVER='dummy',WANDB_MODE='disabled',MPLBACKEND='Agg',VALIDATE_GRAPH='1' if smoke else '0')
  name=('trigger_' if smoke=='trigger' else 'smoke_' if smoke else '')+job['key'].replace('/','_')
  log=ROOT/'logs'/f'{name}.{time.time_ns()}.log'
  cmd=[sys.executable,'-u',str(ROOT/'run_job.py'),'--index',str(index)]+(['--smoke'] if smoke else [])+(['--trigger'] if smoke=='trigger' else [])
  with log.open('x') as f:
   child=subprocess.Popen(cmd,cwd=ROOT,env=env,stdout=f,stderr=subprocess.STDOUT,stdin=subprocess.DEVNULL)
   with LOCK:STATE['running'][name]=dict(gpu=gpu,pid=child.pid,log=str(log));update()
   code=child.wait()
  with LOCK:STATE['running'].pop(name,None);update()
  if code:raise RuntimeError(f'{name}: exit={code} log={log}')
  run(index,smoke) # validates completed receipt and updates counters, without consuming a GPU
 finally:GPUS.put(gpu)
def reuse_completed():
 count=0
 for j in MANIFEST['jobs']:
  source=OLD/'runs'/j['key'];out=ROOT/'runs'/j['key']
  if not (source/'complete.json').exists() or out.exists():continue
  r=json.loads((source/'complete.json').read_text())
  assert r['physics_replay_verified'] and not r['smoke'] and r['tasks']==j['n']
  assert r['checkpoint_sha256']==MANIFEST['checkpoints'][j['checkpoint']]
  out.parent.mkdir(parents=True,exist_ok=True);out.symlink_to(source,target_is_directory=True);count+=1
 update(reused_eager_jobs=count)
def summarize():
 from collections import defaultdict
 counts=defaultdict(lambda:[0,0])
 for j in MANIFEST['jobs']:
  r=json.loads((ROOT/'runs'/j['key']/'complete.json').read_text())
  counts[(j['family'],j['seed'])][0]+=r['successes'];counts[(j['family'],j['seed'])][1]+=r['tasks']
 rows=[]
 for (family,seed),(success,n) in sorted(counts.items()):
  assert n==350
  rows.append(dict(family=family,stage='ecp',seed=seed,successes=success,tasks=n,success_percent=100*success/n))
 (ROOT/'results_new_seeds.json').write_text(json.dumps(rows,indent=2)+'\n')
def main():
 lock=(ROOT/'queue.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 for gpu in [0,1,3,4,5,6,7]:GPUS.put(gpu)
 update(state='validating',pid=os.getpid(),completed_jobs=0,completed_tasks=0,completed_smokes=0,total_jobs=len(MANIFEST['jobs']),total_new_tasks=sum(j['n'] for j in MANIFEST['jobs']),running={})
 try:
  chosen={}
  for i,j in enumerate(MANIFEST['jobs']):chosen.setdefault(j['family'],i)
  triggers=[i for i,j in enumerate(MANIFEST['jobs']) if j['family'] in ('frozen','adajepa') and j['seed']==200 and j['key'].endswith('chunk_04_I')]
  assert len(triggers)==2
  with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:list(pool.map(lambda i:run(i,'trigger'),triggers))
  with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:list(pool.map(lambda i:run(i,True),chosen.values()))
  reuse_completed();update(state='evaluating')
  # Round-robin families to avoid postponing LeWM until the end.
  from itertools import zip_longest
  groups={}
  for i,j in enumerate(MANIFEST['jobs']):groups.setdefault(j['family'],[]).append(i)
  order=[i for batch in zip_longest(*groups.values()) for i in batch if i is not None]
  with concurrent.futures.ThreadPoolExecutor(max_workers=7) as pool:list(pool.map(run,order))
  summarize();update(state='complete')
 except Exception:
  update(state='failed',error=traceback.format_exc());raise
if __name__=='__main__':main()
