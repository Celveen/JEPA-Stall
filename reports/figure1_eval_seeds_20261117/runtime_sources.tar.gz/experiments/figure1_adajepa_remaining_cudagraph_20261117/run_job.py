import argparse,hashlib,json,os,sys,time
from pathlib import Path
ROOT=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def model_hash(m):
 h=hashlib.sha256()
 for k,v in m.state_dict().items():h.update(k.encode());h.update(v.detach().cpu().contiguous().numpy().tobytes())
 return h.hexdigest()
def main():
 p=argparse.ArgumentParser();p.add_argument('--index',type=int,required=True);p.add_argument('--smoke',action='store_true');p.add_argument('--trigger',action='store_true');a=p.parse_args()
 manifest=json.loads((ROOT/'manifest.json').read_text());job=manifest['jobs'][a.index]
 sys.path.insert(0,str(ROOT/'source'/('lewm' if job['family']=='lewm' else 'resnet')))
 import torch,numpy as np
 from omegaconf import OmegaConf
 import plan
 torch.set_num_threads(2);assert torch.cuda.is_available()
 torch.cuda.set_per_process_memory_fraction(10*2**30/torch.cuda.get_device_properties(0).total_memory)
 c=OmegaConf.load(job['config'])
 if a.smoke:
  c.n_evals=1;c.planner.max_iter=30;c.saved_folder=str(ROOT/('smoke_trigger' if a.trigger else 'smoke')/job['family']/job['stage'])
 out=Path(c.saved_folder);out.mkdir(parents=True,exist_ok=False);OmegaConf.save(c,out/'config.yaml')
 cp=Path(job['checkpoint']);assert sha(cp)==manifest['checkpoints'][str(cp)]
 original=plan.load_model;loaded={}
 def load(*args,**kw):
  m=original(*args,**kw)
  if job['family']=='lewm':m.requires_grad_(False).eval()
  loaded.update(model=m,before=model_hash(m));return m
 plan.load_model=load;os.chdir(out);start=time.monotonic()
 plan.planning_main(OmegaConf.to_container(c,resolve=True))
 unchanged=model_hash(loaded['model'])==loaded['before']
 if job['family']!='adajepa':assert unchanged,'Frozen model changed'
 assert sha(cp)==manifest['checkpoints'][str(cp)]
 from datasets.pusht_dset import ACTION_MEAN,ACTION_STD
 from env.pusht.pusht_wrapper import PushTWrapper
 env=PushTWrapper();env.update_env({'shape':'+' if job['shape']=='plus' else job['shape']})
 env._render_frame=lambda *a,**kw:np.zeros((1,1,3),dtype=np.uint8)
 with np.load(out/'final_eval_results.npz') as d:
  assert len(d['successes'])==c.n_evals
  assert d['actions'].shape[1]<=c.planner.max_iter and np.isfinite(d['actions']).all()
  traces=[];successes=[]
  for i in range(c.n_evals):
   _,state=env.prepare(int(c.seed)*i+1,d['state_0'][i]);states=[state]
   controls=d['actions'][i].reshape(-1,2)*ACTION_STD.numpy()+ACTION_MEAN.numpy()
   for action in controls:
    _,_,_,info=env.step(action);states.append(info['state'])
   last=int(min(d['action_len'][i],len(controls)//5))*5
   successes.append(env.eval_state(d['state_g'][i],states[last])['success']);traces.append(states)
  np.testing.assert_array_equal(successes,d['successes'])
  np.savez_compressed(out/'replayed_states.npz',states=np.asarray(traces),goals=d['state_g'],successes=d['successes'],action_len=d['action_len'])
  receipt={**job,'status':'complete','smoke':a.smoke,'tasks':int(c.n_evals),'successes':int(d['successes'].sum()),
           'model_unchanged':unchanged,'checkpoint_sha256':manifest['checkpoints'][str(cp)],'physics_replay_verified':True,
           'cuda_graph':bool(c.planner.sub_planner.cuda_graph),'wall_seconds':time.monotonic()-start}
 env.close();(out/'complete.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt),flush=True)
if __name__=='__main__':main()
