import concurrent.futures
import csv
import fcntl
import json
import os
import queue
import statistics
import subprocess
import sys
import threading
import time
import traceback
from collections import defaultdict
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parent
MANIFEST = json.loads((ROOT / 'manifest.json').read_text())
OLD = Path(MANIFEST['previous_experiment'])
LOCK = threading.RLock()
STATE = {}
GPUS = queue.Queue()


def update(**values):
    with LOCK:
        STATE.update(values, updated_at=datetime.now().astimezone().isoformat())
        tmp = ROOT / 'status.json.tmp'
        tmp.write_text(json.dumps(STATE, indent=2) + '\n')
        tmp.replace(ROOT / 'status.json')


def validate_receipt(path, job, smoke=False):
    receipt = json.loads((path / 'complete.json').read_text())
    assert receipt['physics_replay_verified'] and receipt['smoke'] == smoke
    assert all(receipt[k] == job[k] for k in ('key', 'family', 'stage', 'seed', 'shape', 'checkpoint'))
    assert receipt['tasks'] == (1 if smoke else job['n'])
    assert receipt['checkpoint_sha256'] == MANIFEST['checkpoints'][job['checkpoint']]
    if smoke:
        checks = [json.loads(line) for line in (path / 'graph_validation.jsonl').read_text().splitlines()]
        assert checks and all(c['exact'] and c['rng_equal'] for c in checks)
    return receipt


def record_completion(path, job, smoke):
    receipt = validate_receipt(path, job, smoke)
    with LOCK:
        STATE['completed_smokes' if smoke else 'completed_jobs'] += 1
        if not smoke:
            STATE['completed_tasks'] += receipt['tasks']
        update()


def run(index, smoke=False):
    job = MANIFEST['jobs'][index]
    out = ROOT / 'smoke' / job['family'] / job['stage'] if smoke else ROOT / 'runs' / job['key']
    if (out / 'complete.json').exists():
        record_completion(out, job, smoke)
        return
    gpu = GPUS.get()
    name = ('smoke_' if smoke else '') + job['key'].replace('/', '_')
    try:
        while True:
            free = {
                int(line.split(',')[0]): int(line.split(',')[1])
                for line in subprocess.check_output([
                    'nvidia-smi', '--query-gpu=index,memory.free', '--format=csv,noheader,nounits'
                ], text=True).splitlines()
            }
            if free[gpu] >= 11500:
                break
            time.sleep(15)
        if out.exists():
            out.rename(out.with_name(out.name + '.incomplete.' + str(time.time_ns())))
        env = dict(os.environ, CUDA_VISIBLE_DEVICES=str(gpu), OMP_NUM_THREADS='2', MKL_NUM_THREADS='2',
                   OPENBLAS_NUM_THREADS='1', PYTHONDONTWRITEBYTECODE='1', SDL_VIDEODRIVER='dummy',
                   SDL_AUDIODRIVER='dummy', WANDB_MODE='disabled', MPLBACKEND='Agg',
                   VALIDATE_GRAPH='1' if smoke else '0')
        log = ROOT / 'logs' / f'{name}.{time.time_ns()}.log'
        command = [sys.executable, '-u', str(ROOT / 'run_job.py'), '--index', str(index)]
        if smoke:
            command.append('--smoke')
        with log.open('x') as output:
            child = subprocess.Popen(command, cwd=ROOT, env=env, stdout=output,
                                     stderr=subprocess.STDOUT, stdin=subprocess.DEVNULL)
            with LOCK:
                STATE['running'][name] = dict(gpu=gpu, pid=child.pid, log=str(log))
                update()
            code = child.wait()
        if code:
            raise RuntimeError(f'{name}: exit={code}; log={log}')
        record_completion(out, job, smoke)
    except Exception as error:
        with LOCK:
            STATE['failures'].append(dict(job=name, error=str(error)))
            update()
        raise
    finally:
        with LOCK:
            STATE['running'].pop(name, None)
            update()
        GPUS.put(gpu)


def reuse_completed():
    from omegaconf import OmegaConf
    jobs = tasks = 0
    for job in MANIFEST['jobs']:
        source = OLD / 'runs' / job['key']
        out = ROOT / 'runs' / job['key']
        if not (source / 'complete.json').exists():
            continue
        receipt = validate_receipt(source, job)
        original = OmegaConf.to_container(OmegaConf.load(source / 'config.yaml'), resolve=True)
        current = OmegaConf.to_container(OmegaConf.load(job['config']), resolve=True)
        for cfg in (original, current):
            cfg.pop('saved_folder', None)
            cfg['planner']['sub_planner'].pop('cuda_graph', None)
        assert original == current, f'Changed evaluation protocol: {job["key"]}'
        if not out.exists():
            out.parent.mkdir(parents=True, exist_ok=True)
            out.symlink_to(source, target_is_directory=True)
        if out.is_symlink():
            jobs += 1
            tasks += receipt['tasks']
    update(reused_eager_jobs=jobs, reused_eager_tasks=tasks)


def summarize():
    counts = defaultdict(lambda: [0, 0])
    for job in MANIFEST['jobs']:
        receipt = validate_receipt(ROOT / 'runs' / job['key'], job)
        key = (job['stage'], job['seed'])
        counts[key][0] += receipt['successes']
        counts[key][1] += receipt['tasks']
    rows = []
    for (stage, seed), (success, tasks) in sorted(counts.items()):
        assert tasks == 350
        rows.append(dict(family='adajepa', stage=stage, seed=seed, successes=success,
                         tasks=tasks, success_percent=100 * success / tasks))
    (ROOT / 'results_new_seeds.json').write_text(json.dumps(rows, indent=2) + '\n')

    ecp_root = Path(MANIFEST['ecp_experiment'])
    ecp_manifest = json.loads((ecp_root / 'manifest.json').read_text())
    ecp_counts = defaultdict(lambda: [0, 0])
    for job in ecp_manifest['jobs']:
        if job['family'] != 'adajepa':
            continue
        receipt = validate_receipt(ecp_root / 'runs' / job['key'], job)
        ecp_counts[job['seed']][0] += receipt['successes']
        ecp_counts[job['seed']][1] += receipt['tasks']
    for seed, (success, tasks) in ecp_counts.items():
        assert tasks == 350
        counts[('ecp', seed)] = [success, tasks]
    historical = json.loads((ROOT / 'historical_figure1.json').read_text())
    old = next(g for g in historical['groups'] if g['label'].lower() == 'adajepa')
    per_seed = []
    summary = []
    for index, stage in enumerate(['base', 'aug', 'ecp']):
        seeds = [MANIFEST['historical_seeds']['adajepa']] + MANIFEST['new_seeds']['adajepa']
        values = [old['success_counts'][index]] + [counts[stage, seed][0] for seed in seeds[1:]]
        rates = [100 * value / 350 for value in values]
        summary.append(dict(family='adajepa', stage=stage, seeds=seeds, counts=values,
                            tasks_per_seed=350, mean_percent=statistics.mean(rates),
                            sample_std_percent=statistics.stdev(rates)))
        for seed, success, rate in zip(seeds, values, rates):
            per_seed.append(dict(family='adajepa', stage=stage, seed=seed, successes=success,
                                 tasks=350, success_percent=rate,
                                 source='historical' if seed == seeds[0] else 'evaluated'))
    (ROOT / 'results_adajepa_three_seeds.json').write_text(json.dumps(dict(
        evaluation_seed_replicates_only=True, fixed_task_lists=True, results=summary), indent=2) + '\n')
    with (ROOT / 'per_seed.csv').open('w', newline='') as output:
        writer = csv.DictWriter(output, fieldnames=list(per_seed[0]), lineterminator='\n')
        writer.writeheader()
        writer.writerows(per_seed)


def main():
    lock = (ROOT / 'queue.lock').open('a')
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    assert all(j['family'] == 'adajepa' and j['stage'] in ('base', 'aug') for j in MANIFEST['jobs'])
    for gpu in [0, 1, 3, 4, 5, 6, 7]:
        GPUS.put(gpu)
    update(state='validating', pid=os.getpid(), completed_jobs=0, completed_tasks=0, completed_smokes=0,
           total_jobs=len(MANIFEST['jobs']), total_new_tasks=sum(j['n'] for j in MANIFEST['jobs']),
           running={}, failures=[], started_at=datetime.now().astimezone().isoformat())
    try:
        chosen = {}
        for i, job in enumerate(MANIFEST['jobs']):
            chosen.setdefault(job['stage'], i)
        assert set(chosen) == {'base', 'aug'}
        with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
            list(pool.map(lambda index: run(index, True), chosen.values()))
        reuse_completed()
        update(state='evaluating')
        from itertools import zip_longest
        groups = defaultdict(list)
        for i, job in enumerate(MANIFEST['jobs']):
            groups[job['stage']].append(i)
        order = [i for batch in zip_longest(*groups.values()) for i in batch if i is not None]
        with concurrent.futures.ThreadPoolExecutor(max_workers=7) as pool:
            list(pool.map(run, order))
        summarize()
        update(state='complete', completed_at=datetime.now().astimezone().isoformat())
    except Exception:
        update(state='failed', error=traceback.format_exc())
        raise


if __name__ == '__main__':
    main()
