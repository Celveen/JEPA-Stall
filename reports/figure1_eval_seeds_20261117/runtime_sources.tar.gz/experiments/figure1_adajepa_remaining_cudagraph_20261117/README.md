# Figure 1: remaining AdaJEPA conditions

Scope: base data and augmented data without ECP, evaluation seeds 200/300 only.
Frozen/LeWM base and augmentation repeats are deferred by user: deterministic planning on fixed tasks.
Keep checkpoint hashes, 350 tasks per condition/seed, GD100, 30 replans, five controls per replan.
Use the verified CUDA Graph implementation from figure1_ecp_cudagraph_20261117.
First validate eager/graph actions and RNG exactly, plus physical replay, on both conditions.
Then reuse original completed receipts and run only missing jobs. Partial results stay archived.
The seven workers use GPUs 0,1,3,4,5,6,7, with a free-memory check; GPU 2 is excluded.
On completion, results_new_seeds.json contains the four new condition/seed counts;
results_adajepa_three_seeds.json and per_seed.csv also include completed ECP results and historical seeds.
These are evaluation-seed replicates on fixed task lists, not independently trained model replicates.
