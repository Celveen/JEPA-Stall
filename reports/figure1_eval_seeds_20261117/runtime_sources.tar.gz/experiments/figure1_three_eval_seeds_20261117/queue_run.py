import concurrent.futures,fcntl,json,os,subprocess,sys,threading,time,traceback
from datetime import datetime
from pathlib import Path
import queue
ROOT=Path(__file__).resolve().parent
LOCK=threading.RLock();STATE={};GPUS=queue.Queue()
def now():return datetime.now().astimezone().isoformat()
def update(**kw):
 with LOCK:
  STATE.update(kw,updated_at=now());p=ROOT/'status.json.tmp';p.write_text(json.dumps(STATE,indent=2)+'\n');p.replace(ROOT/'status.json')
def run(index,smoke=False):
 job=MANIFEST['jobs'][index]
 if smoke:
  marker=ROOT/'smoke'/job['family']/job['stage']/'complete.json'
  if marker.exists():
   receipt=json.loads(marker.read_text());assert receipt['physics_replay_verified'] and receipt['smoke']
   with LOCK:STATE['completed_smokes']+=1;update()
   return 0
 gpu=GPUS.get()
 try:
  while True:
   free={int(s.split(',')[0]):int(s.split(',')[1])for s in subprocess.check_output(['nvidia-smi','--query-gpu=index,memory.free','--format=csv,noheader,nounits'],text=True).splitlines()}
   if free[gpu]>=11500:break
   time.sleep(15)
  name=('smoke_' if smoke else '')+job['key'].replace('/','_');log=ROOT/'logs'/f'{name}.log'
  command=[sys.executable,'-u',str(ROOT/'run_job.py'),'--index',str(index)]+(['--smoke']if smoke else [])
  env=dict(os.environ,CUDA_VISIBLE_DEVICES=str(gpu),OMP_NUM_THREADS='2',MKL_NUM_THREADS='2',OPENBLAS_NUM_THREADS='1',PYTHONDONTWRITEBYTECODE='1',SDL_VIDEODRIVER='dummy',SDL_AUDIODRIVER='dummy',WANDB_MODE='disabled',MPLBACKEND='Agg')
  with log.open('x')as f:
   child=subprocess.Popen(command,cwd=ROOT,env=env,stdout=f,stderr=subprocess.STDOUT,stdin=subprocess.DEVNULL)
   with LOCK:STATE['running'][name]={'gpu':gpu,'pid':child.pid,'started_at':now()};update()
   code=child.wait()
  with LOCK:
   STATE['running'].pop(name,None)
   if code:STATE['failures'].append({'job':name,'returncode':code,'log':str(log)})
   else:
    out=ROOT/'smoke'/job['family']/job['stage'] if smoke else ROOT/'runs'/job['key']
    receipt=json.loads((out/'complete.json').read_text())
    STATE['completed_smokes' if smoke else 'completed_jobs']+=1
    if not smoke:STATE['completed_tasks']+=receipt['tasks']
   update()
  return code
 finally:GPUS.put(gpu)
def summarize():
 import csv,numpy as np
 from collections import defaultdict
 old=json.loads((ROOT/'historical_figure1.json').read_text());historical={g['label'].lower():g['success_counts']for g in old['groups']}
 counts=defaultdict(lambda:[0,0]);shape_counts=defaultdict(lambda:[0,0])
 for job in MANIFEST['jobs']:
  m=json.loads((ROOT/'runs'/job['key']/'complete.json').read_text());assert m['physics_replay_verified'] and not m['smoke']
  key=(job['family'],job['stage'],job['seed']);counts[key][0]+=m['successes'];counts[key][1]+=m['tasks']
  shape_counts[key+(job['shape'],)][0]+=m['successes'];shape_counts[key+(job['shape'],)][1]+=m['tasks']
 rows=[];summary=[]
 for family in ['frozen','lewm','adajepa']:
  for i,stage in enumerate(['base','aug','ecp']):
   seeds=[MANIFEST['historical_seeds'][family]]+MANIFEST['new_seeds'][family]
   values=[historical[family][i]]
   for seed in seeds[1:]:
    success,n=counts[family,stage,seed];assert n==350;values.append(success)
   for seed,count in zip(seeds,values):rows.append(dict(model=family,stage=stage,seed=seed,successes=count,tasks=350,success_percent=100*count/350,source='historical' if seed==seeds[0] else 'new'))
   rates=np.array(values)*100/350
   summary.append(dict(model=family,stage=stage,counts=values,seeds=seeds,mean_percent=float(rates.mean()),sample_std_percent=float(rates.std(ddof=1))))
 with (ROOT/'per_seed.csv').open('w',newline='')as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]),lineterminator='\n');w.writeheader();w.writerows(rows)
 with (ROOT/'per_shape_new_seeds.csv').open('w',newline='')as f:
  w=csv.writer(f,lineterminator='\n');w.writerow(['model','stage','seed','shape','successes','tasks'])
  for k,v in sorted(shape_counts.items()):w.writerow([*k,*v])
 (ROOT/'results.json').write_text(json.dumps({'evaluation_seed_replicates_only':True,'new_tasks':6300,'results':summary},indent=2)+'\n')
 lines=['# Figure 1: three evaluation seeds','', '| Model | Configuration | Per-seed successes /350 | Mean ± sample SD (%) |','|---|---|---|---|']
 for r in summary:lines.append(f"| {r['model']} | {r['stage']} | {r['counts']} | {r['mean_percent']:.2f} ± {r['sample_std_percent']:.2f} |")
 (ROOT/'RESULTS.md').write_text('\n'.join(lines)+'\n')
def main():
 global MANIFEST
 lock=(ROOT/'queue.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 MANIFEST=json.loads((ROOT/'manifest.json').read_text());(ROOT/'logs').mkdir(exist_ok=True)
 for gpu in [0,1,3,4,5,6,7]:GPUS.put(gpu)
 update(state='preflight',pid=os.getpid(),started_at=now(),completed_jobs=0,completed_smokes=0,completed_tasks=0,total_jobs=462,total_new_tasks=6300,running={},failures=[])
 try:
  chosen={}
  for i,j in enumerate(MANIFEST['jobs']):chosen.setdefault((j['family'],j['stage']),i)
  with concurrent.futures.ThreadPoolExecutor(max_workers=7)as pool:
   results=list(pool.map(lambda i:run(i,True),chosen.values()))
  assert not any(results),'Smoke failed; full queue not started'
  update(state='evaluating')
  with concurrent.futures.ThreadPoolExecutor(max_workers=7)as pool:
   from itertools import zip_longest
   groups={}
   for i,j in enumerate(MANIFEST['jobs']):groups.setdefault((j['family'],j['stage']),[]).append(i)
   order=[i for batch in zip_longest(*groups.values()) for i in batch if i is not None]
   futures=[pool.submit(run,i)for i in order]
   for future in concurrent.futures.as_completed(futures):future.result()
  assert not STATE['failures'],'Some jobs failed; raw outputs preserved'
  summarize();update(state='complete',completed_at=now())
 except Exception:
  update(state='failed',error=traceback.format_exc());raise
if __name__=='__main__':main()
