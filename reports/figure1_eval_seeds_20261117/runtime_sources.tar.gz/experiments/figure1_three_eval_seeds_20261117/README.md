# Figure 1: two additional evaluation seeds

Nine conditions: Frozen, LeWM, AdaJEPA × base data, augmented data, augmented data + ECP.
Preserve published seed 100 (ResNet) or 2000 (LeWM); evaluate only seeds 200/300 or 2001/2002 respectively.
There are 462 new jobs and 6300 task executions, with 350 tasks per condition per seed.
Checkpoints and task lists are unchanged. These are evaluation-seed replicates, not independently trained models.
Report mean and sample standard deviation over the three per-seed success rates; retain each seed's counts.
Frozen/AdaJEPA use the original EVAL50 chunks; LeWM uses its original H7t3 list.
GD100, 30 replans × 5 controls; ECP thresholds 0.15/0.45. LeWM keeps contact objective weight 10.
Native historical 40-replan runs contribute their already published 30-replan censored counts.
Full source snapshots prevent later GitHub synchronization from altering a running job.
The queue first checks all nine conditions with short smoke runs, excluded from results,
then launches the full jobs. All new outcomes must match physical replay.
Existing unrelated GPU processes are never terminated. Logs, configs, model checks, target states,
actual actions and replayed states are retained per job. Output directories are never overwritten.
