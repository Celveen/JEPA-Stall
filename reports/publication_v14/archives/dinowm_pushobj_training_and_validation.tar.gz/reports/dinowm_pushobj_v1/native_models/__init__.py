"""DINO-WM official modules, pinned at 0a9492fa12044b852ae9e001cc74604b79c8bb0c."""
