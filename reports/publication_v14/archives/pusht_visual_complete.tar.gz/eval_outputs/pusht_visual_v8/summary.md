# PushT evaluation completed

All 56 jobs completed (2,800 episode-runs). Each native/ECP comparison uses the same 50 tasks. Pre-trigger action equivalence passed for all 1,400 paired episodes.

| Checkpoint / condition / update | Native (%) | ECP (%) | Gain (pp) | Rescues | Regressions |
|---|---:|---:|---:|---:|---:|
| released/clean/seed100/frozen | 60.0 | 68.0 | +8.0 | 4 | 0 |
| released/clean/seed100/adajepa | 82.0 | 84.0 | +2.0 | 1 | 0 |
| augmented/clean/seed100/frozen | 72.0 | 82.0 | +10.0 | 5 | 0 |
| augmented/clean/seed100/adajepa | 86.0 | 86.0 | +0.0 | 0 | 0 |
| released/redBlock/seed100/frozen | 10.0 | 10.0 | +0.0 | 0 | 0 |
| released/redBlock/seed100/adajepa | 10.0 | 10.0 | +0.0 | 0 | 0 |
| augmented/redBlock/seed100/frozen | 12.0 | 12.0 | +0.0 | 1 | 1 |
| augmented/redBlock/seed100/adajepa | 16.0 | 18.0 | +2.0 | 1 | 0 |
| released/redAnchor/seed100/frozen | 36.0 | 38.0 | +2.0 | 1 | 0 |
| released/redAnchor/seed100/adajepa | 40.0 | 40.0 | +0.0 | 0 | 0 |
| augmented/redAnchor/seed100/frozen | 18.0 | 34.0 | +16.0 | 8 | 0 |
| augmented/redAnchor/seed100/adajepa | 42.0 | 42.0 | +0.0 | 1 | 1 |
| released/redAgent/seed100/frozen | 56.0 | 56.0 | +0.0 | 0 | 0 |
| released/redAgent/seed100/adajepa | 60.0 | 62.0 | +2.0 | 1 | 0 |
| augmented/redAgent/seed100/frozen | 56.0 | 68.0 | +12.0 | 6 | 0 |
| augmented/redAgent/seed100/adajepa | 64.0 | 68.0 | +4.0 | 2 | 0 |
| released/blur/seed100/frozen | 50.0 | 56.0 | +6.0 | 3 | 0 |
| released/blur/seed100/adajepa | 76.0 | 80.0 | +4.0 | 2 | 0 |
| augmented/blur/seed100/frozen | 58.0 | 72.0 | +14.0 | 7 | 0 |
| augmented/blur/seed100/adajepa | 82.0 | 86.0 | +4.0 | 2 | 0 |
| released/snp/seed100/frozen | 60.0 | 60.0 | +0.0 | 0 | 0 |
| released/snp/seed100/adajepa | 76.0 | 78.0 | +2.0 | 1 | 0 |
| augmented/snp/seed100/frozen | 62.0 | 70.0 | +8.0 | 4 | 0 |
| augmented/snp/seed100/adajepa | 80.0 | 80.0 | +0.0 | 0 | 0 |
| released/dark/seed100/frozen | 52.0 | 58.0 | +6.0 | 3 | 0 |
| released/dark/seed100/adajepa | 76.0 | 80.0 | +4.0 | 2 | 0 |
| augmented/dark/seed100/frozen | 70.0 | 78.0 | +8.0 | 4 | 0 |
| augmented/dark/seed100/adajepa | 86.0 | 88.0 | +2.0 | 1 | 0 |
